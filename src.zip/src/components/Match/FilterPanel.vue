<template>
    <v-container fluid>
        <v-row class="no-gutters" justify="center">
            <v-col cols="7" lg="9">
                <v-select
                    v-model="chosenLeagues"
                    :items="leagues"
                    item-text="league_name"
                    item-value="league_id"
                    height="12"
                    attach
                    label="Tournament"
                    hide-details
                    multiple
                ></v-select>
            </v-col>

            <v-col cols="5" lg="3">
                <v-select
                    v-model="chosenSeasons"
                    :items="seasons"
                    label="Season"
                    height="12"
                    attach
                    hide-details
                    multiple
                />
            </v-col>
        </v-row>

        <v-row justify="start" style="align-items: center">
            <v-col cols="2">
                <v-select
                    v-model="fullHalf"
                    :items="timeCategories"
                    item-text="text"
                    item-value="index"
                    label="Time"
                    attach
                    hide-details
                />
            </v-col>

            <v-col v-if="local_coach && visitor_coach" cols="4" class="d-flex justify-space-around">
                <div>
                    <input type="checkbox" v-model="currentCoach">
                    <span>Current Coach</span>
                </div>

                <div>
                    <input type="checkbox" v-model="prevCoach">
                    <span>Previous Coach</span>
                </div>
            </v-col>

            <v-col cols="2" class="d-flex justify-space-around">
                <div>
                    <input type="checkbox" v-model="local">
                    <span>Home</span>
                </div>

                <div>
                    <input type="checkbox" v-model="visitor">
                    <span>Away</span>
                </div>
            </v-col>

            <v-col cols="2">
                <v-select
                    v-model="perPage"
                    :items="countPerPage"
                    attach
                    hide-details
                />
            </v-col>

            <v-col cols="1">
                <input
                    :number="perPageByUser"
                    type=number
                    min=1
                    max=149
                    style="border: 1px solid; width: 70px; padding-left: 5px"
                    v-on:keyup.enter="perPageChange">
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
export default {
    name: 'match-filter-panel',
    props: [
        // indicate if head-to-head, last, similar, referee
        'type',
        'leagues',
        'seasons',
        'local_coach',
        'visitor_coach',
    ],
    data() {
        return {
            // tz: localStorage.tz ? localStorage.tz : '+0',
            // favorite_league: localStorage.favorite_league ? JSON.parse(localStorage.favorite_league) : [],
            // expanding_league: localStorage.expanding_league ? JSON.parse(localStorage.expanding_league) : [],
            // odds_format: localStorage.odds_format ? localStorage.odds_format : 0,
            // matches: [],
            // isLoaded: false,
            chosenLeagues: [],
            chosenSeasons: [],
            fullHalf: 0,
            currentCoach: false,
            prevCoach: false,
            local: false,
            visitor: false,
            perPage: 20,
            perPageByUser: '',
            countPerPage: [20, 30, 40, 60, 80, 'All'],
            h2hCountPerPage: [5, 10, 20, 30, 50, 'All'],
            timeCategories: [
                {text: 'Full time', index: 0},
                {text: '1 half', index: 1},
                {text: '2 half', index: 2}]
        }
    },

    watch: {
        chosenLeagues: function (val) {
            this.changeQSeasons(1)
        },

        chosenSeasons: function (val) {
            this.changeQSeasons(1)
        },

        currentCoach (val) {
            this.homePage = 0
            this.hLastPage = -1
            this.Hlast = []
            this.lastHomeLoaded = false
            
            this.getLast(1)
        },

        prevCoach (val) {
            this.homePage = 0
            this.hLastPage = -1
            this.Hlast = []
            this.lastHomeLoaded = false
            
            this.getLast(1)
        },

        local (val) {
            if (!val && !this.hVisitor) {
                this.hLocal = !val
            }else {
                this.homePage = 0
                this.hLastPage = -1
                this.Hlast = []
                this.lastHomeLoaded = false

                this.getLast(1)
            }
        },
        
        visitor (val) {
            if (!val && !this.hLocal) {
                this.hVisitor = !val
            }else {
                this.homePage = 0
                this.hLastPage = -1
                this.Hlast = []
                this.lastHomeLoaded = false

                this.getLast(1)
            }
        },    

        fullHalf (val) {
            this.h2hLoaded = false
            this.originCGC = []
            this.filteredCGC = []
            this.get_cgc()
            this.changeH2HFilter()
        }
    },

    methods: {
        handleClick(evt) {
            this.$emit('click', evt);
        },

        perPageChange(evt) {

        }
    }
}
</script>