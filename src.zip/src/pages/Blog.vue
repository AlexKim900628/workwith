<template>
  <v-app>
    <v-card class="blog-table">
      <div v-if="!isLoaded" >
          <div class="ripple_loading"><img src="/img/icons/Ripple-1s-200px.png"></div>
      </div>

      <v-card-title v-else>
        Blogs

        <v-spacer></v-spacer>
        
        <v-btn v-if="isAdmin" class="ma-2" tile outlined color="primary" @click="newBlog()">
          <v-icon left>mdi-plus</v-icon> New Blog
        </v-btn>
      </v-card-title>

      <v-data-table
        v-if="isLoaded"
        :headers="computedHeaders"
        :items="items"
        :search="search"
        class="elevation-1"
        :mobile-breakpoint="0"
      >
        <template v-slot:item="props">
          <tr>
            <td>
              <router-link :to="{name: 'article', params: { id: props.item.id }}">
                {{props.item.title}}
              </router-link>
            </td>

            <td class="d-none d-sm-table-cell">{{ props.item.published | moment('MMMM d, YYYY') }}</td>

            <td v-if="isAdmin">
              <v-icon
                class="mr-2"
                color="blue"
                @click="editItem(props.item.id)">
                mdi-pencil
              </v-icon>

              <v-icon
                color="orange"
                @click="deleteItem(props.item.id)">
                mdi-delete
              </v-icon>
            </td>
          </tr>
        </template>
      </v-data-table>
    </v-card>
  </v-app>
</template>

<script>
  import axios from 'axios'
  import config from '@/config'
  import moment from 'moment-timezone'

  axios.defaults.baseURL = config.API_URL;

  export default {
    data () {
      return {
        tz: '',
        search: '',
        isLoaded: false,
        isAdmin: localStorage.uid ? localStorage.uid === 'admin' : false,
        headers: [
          {
            text: 'Title',
            align: 'start',
            sortable: false,
            value: 'title',
          },
          { text: 'Published', value: '', align: 'start d-none d-sm-table-cell', sortable: false },
          { text: 'Action', value: '', sortable: false },
        ],
        items: [
          {
            id: '',
            title: '',
            published: '',
          }
        ],
      }
    },
    computed: {
        computedHeaders () {
            if (this.isAdmin) return this.headers
            else return this.headers.filter(header => header.text !== "Action")  
        }
    },
    mounted() {
        this.blog_list()
    },
    methods: {
        async blog_list() {
            this.tz = localStorage.tz ? localStorage.tz : '+0'
            
            //Etc/GMT-X will have an offset of +X and Etc/GMT+X will have an offset of -X.
            moment.tz.setDefault('Etc/GMT' + this.tz)
            
            axios
            .get('/get_blog/')
            .then((response) => {
                this.isLoaded = true
                this.items = response.data
            })
        },
        editItem (id) {
            this.$router.replace('/edit/'+id)
        },
        deleteItem (id) {
            if (confirm('Are you sure you want to delete this Blog?')) {
                axios
                .post('/del_article/', {id: id}, { 'headers': { 'Authorization': 'Token ' + localStorage.token } })
                .then((response) => {
                  this.blog_list()
                })
                .catch((err) => {
                  localStorage.removeItem('token')
                  localStorage.removeItem('uid')
                  location.reload()
                })
            }
        },
        newBlog () {
            this.$router.replace('/edit/new')
        }
    }
  }
</script>
<style>
  .blog-table {
    margin: 25vh 10vw 20vh 10vw;
    cursor: pointer;
  }

  @media (max-width: 450px) {
    .blog-table {
      margin: 15vh 2vw 2vh 2vw;
    }
  }
</style>