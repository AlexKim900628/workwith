<template>
    <div v-if="isAuth">
        <div v-if="!isLoaded" >
            <div class="ripple_loading"><img src="/img/icons/Ripple-1s-200px.png"></div>
        </div>
        
        <v-container class="post">
            <v-textarea
                solo
                rows="2"
                class="card-title"
                label="Title"
                v-model="posts.title"
            ></v-textarea>

            <quill-editor
                v-model="posts.data"
                contentType="html"
                theme="snow"
                >
            </quill-editor>

            <div class="footer">
                <v-btn @click="save()">
                    <v-icon
                        class="mr-2"
                        color="blue"
                    >
                        mdi-content-save
                    </v-icon>

                    Save
                </v-btn>

                <v-btn style="float: right" @click="cancel()">
                    <v-icon
                        class="mr-2"
                        color="blue"
                    >
                        mdi-undo
                    </v-icon>
                    
                    Cancel
                </v-btn>
            </div>
        </v-container>
    </div>
</template>

<script>
  import axios from 'axios';
  import config from '@/config'
  import { quillEditor } from 'vue-quill-editor'
  import 'quill/dist/quill.core.css'
  import 'quill/dist/quill.snow.css'
  import 'quill/dist/quill.bubble.css'

  axios.defaults.baseURL = config.API_URL;

  export default {
    data () {
      return {
        isLoaded: false,
        isAuth: false,
        id: this.$route.params.id,
        posts: 
            {
                title: '',
                data: '',
                published: '',
            },
        editorOption: {
            debug: 'info',
            modules: {
                toolbar: '#toolbar'
            },
            theme: 'snow'
            }
      }
    },
    components: {
        quillEditor
    },
    mounted() {
        this.authenticate()
    },
    methods: {
        async authenticate () {
            if (localStorage.uid == 'admin') {
                this.isAuth = true

                if (this.id != 'new') {
                    axios
                    .get('/article/'+this.$route.params.id)
                    .then((response) => {
                        this.isLoaded = true
                        this.posts = response.data[0]
                    })
                    .catch((err) => {
                        this.message = 'Invalid Credentials.'
                    })
                }
            }
        },
        save() {
            if (this.posts.title != '' && this.posts.content != '') {
                axios
                    .post('/save_article/', 
                        {id: this.id, title: this.posts.title, data: this.posts.data},
                        { 'headers': { 'Authorization': 'Token ' + localStorage.token } })
                    .then((response) => {
                        this.$router.replace('/blog/')
                    })
                    .catch((err) => {
                        localStorage.removeItem('token')
                        localStorage.removeItem('uid')
                        location.reload();
                    })
            }
        },
        cancel() {
            this.$router.replace('/blog/')
        }
    }
  }
</script>
<style>
    /* .footer {
        margin-top: 15px;
    } */
</style>